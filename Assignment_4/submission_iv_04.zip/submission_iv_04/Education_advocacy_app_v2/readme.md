
# React App with Vite

This project is a React application bootstrapped with [Vite](https://vitejs.dev/). It uses JavaScript as the primary language.

## Prerequisites

Before you begin, ensure you have the following installed on your system:

- [Node.js](https://nodejs.org/) (version 14 or higher)
- [npm](https://www.npmjs.com/) (comes with Node.js) or [yarn](https://yarnpkg.com/)

## Installation

1. Save the code

2. Install dependencies:

   Using npm:

   ```bash
   npm install
   ```

   Or using yarn:

   ```bash
   yarn install
   ```

## Running the Application

1. Start the development server:

   Using npm:

   ```bash
   npm run dev
   ```

   Or using yarn:

   ```bash
   yarn dev
   ```

2. Open your browser and navigate to the URL displayed in the terminal, typically:

   ```
   http://localhost:5173
   ```

## Building for Production

To create a production-ready build of the application:

Using npm:

```bash
npm run build
```

Or using yarn:

```bash
yarn build
```

The output will be stored in the `dist` directory.

## Previewing the Build

To preview the production build locally:

Using npm:

```bash
npm run preview
```

Or using yarn:

```bash
yarn preview
```


