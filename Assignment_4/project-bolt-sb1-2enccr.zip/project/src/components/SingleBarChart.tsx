import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface SingleBarChartProps {
  type: 'earnings' | 'unemployment' | 'poverty';
  value: number;
  previousValue: number | null;
  maxValue: number;
}

export const SingleBarChart: React.FC<SingleBarChartProps> = ({ type, value, previousValue, maxValue }) => {
  const chartRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!chartRef.current) return;

    d3.select(chartRef.current).selectAll('*').remove();

    const svg = d3.select(chartRef.current);
    const width = chartRef.current.clientWidth;
    const height = chartRef.current.clientHeight;
    const margin = { top: 20, right: 20, bottom: 40, left: 60 };

    const chartWidth = width - margin.left - margin.right;
    const chartHeight = height - margin.top - margin.bottom;

    const g = svg
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const y = d3.scaleLinear()
      .domain([0, maxValue])
      .range([chartHeight, 0]);

    // Add Y axis
    g.append('g')
      .call(d3.axisLeft(y).ticks(5)
        .tickFormat(d => type === 'earnings' ? `$${d/1000}k` : `${d}%`));

    const barWidth = chartWidth / 3;
    const spacing = barWidth / 2;

    // Add previous bar if exists
    if (previousValue !== null) {
      const previousBar = g.append('rect')
        .attr('x', chartWidth / 4 - spacing)
        .attr('width', barWidth)
        .attr('y', chartHeight)
        .attr('height', 0)
        .attr('fill', '#8E8E93')
        .attr('rx', 6)
        .attr('opacity', 0.7);

      // Animate previous bar
      previousBar.transition()
        .duration(750)
        .attr('y', y(previousValue))
        .attr('height', chartHeight - y(previousValue));

      // Add previous value label
      g.append('text')
        .attr('class', 'value-label')
        .attr('x', chartWidth / 4 - spacing + barWidth / 2)
        .attr('y', y(previousValue) - 10)
        .attr('text-anchor', 'middle')
        .attr('fill', '#8E8E93')
        .text(type === 'earnings' ? `$${previousValue.toLocaleString()}` : `${previousValue}%`);
    }

    // Add current bar
    const currentBar = g.append('rect')
      .attr('x', chartWidth / 4 + (previousValue !== null ? spacing : 0))
      .attr('width', barWidth)
      .attr('y', chartHeight)
      .attr('height', 0)
      .attr('fill', '#06c')
      .attr('rx', 6);

    // Animate current bar
    currentBar.transition()
      .duration(750)
      .attr('y', y(value))
      .attr('height', chartHeight - y(value));

    // Add current value label
    g.append('text')
      .attr('class', 'value-label')
      .attr('x', chartWidth / 4 + (previousValue !== null ? spacing : 0) + barWidth / 2)
      .attr('y', y(value) - 10)
      .attr('text-anchor', 'middle')
      .attr('fill', '#06c')
      .text(type === 'earnings' ? `$${value.toLocaleString()}` : `${value}%`);

    // Add legend if there's a previous value
    if (previousValue !== null) {
      const legend = g.append('g')
        .attr('transform', `translate(${chartWidth - 120}, ${margin.top})`);

      // Previous value legend
      legend.append('rect')
        .attr('width', 12)
        .attr('height', 12)
        .attr('rx', 2)
        .attr('fill', '#8E8E93')
        .attr('opacity', 0.7);

      legend.append('text')
        .attr('x', 20)
        .attr('y', 10)
        .attr('fill', '#8E8E93')
        .style('font-size', '12px')
        .text('Previous');

      // Current value legend
      legend.append('rect')
        .attr('width', 12)
        .attr('height', 12)
        .attr('rx', 2)
        .attr('y', 20)
        .attr('fill', '#06c');

      legend.append('text')
        .attr('x', 20)
        .attr('y', 30)
        .attr('fill', '#06c')
        .style('font-size', '12px')
        .text('Current');
    }

  }, [type, value, previousValue, maxValue]);

  return (
    <svg
      ref={chartRef}
      className="w-full h-full"
      style={{ minHeight: '300px' }}
    />
  );
};